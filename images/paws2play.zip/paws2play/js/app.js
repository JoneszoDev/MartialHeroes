
var signup = new gpSignupData (p2pConfig.apiBase, p2pConfig.charityId, p2pConfig.campaignId);

$(document).ready(function() {

	var navListItems = $('div.setup-panel div a'),
	allWells = $('.setup-content'),
	allErrors = $('.error'),
	allNextBtn = $('.nextBtn, .nextBtnTwitch');
	allFields = $('#multistep input, #multistep select, .date');
	allDownload = $('.download');

	if ( $('#date')[0].type != 'date' ) { $('#date').datepicker({ dateFormat: 'dd-mm-yy' }) };

	allWells.hide();

	allFields.blur(function(e){
		if (e.target.name == 'marketing-preferences') {
			if (e.target.id == 'optin') {
				signup.addData('isOptedInToMarketing', true);
				return;
			}
			signup.addData('isOptedInToMarketing', false);
			return;
		}
		if (e.target.id == 'team-rabbit') {
			signup.setGroup(p2pConfig.teamGroupsId, p2pConfig.teamRabbitGroupId);
			return;
		}
		if (e.target.id == 'team-cat') {
			signup.setGroup(p2pConfig.teamGroupsId, p2pConfig.teamCatGroupId);
			return;
		}
		if (e.target.id == 'team-dog') {
			signup.setGroup(p2pConfig.teamGroupsId, p2pConfig.teamDogGroupId);
			return;
		}
		if (e.target.id == 'team-horse') {
			signup.setGroup(p2pConfig.teamGroupsId, p2pConfig.teamHorseGroupId);
			return;
		}
		if (e.target.id == 'pet-select') {
			switch (e.target.value) {
				case 'twitch':
					signup.addData('templateChallengeId', p2pConfig.twitchTemplateId);
					signup.addData('Platform', 'Twitch');
					break;
				case 'mixer':
					signup.addData('templateChallengeId', p2pConfig.mixerTemplateId);
					signup.addData('Platform', 'Mixer');
					break;
				case 'youtube':
					signup.addData('templateChallengeId', p2pConfig.youtubeTemplateId);
					signup.addData('Platform', 'YouTube');
					break;
			}
			return;
		}
	
		signup.addData(e.target.name, e.target.value);
	});

	allDownload.click(function(e){
	 	/* No tracking for now */
	});

	navListItems.click(function(e) {
		e.preventDefault();
		var $target = $($(this).attr('href')),
		$item = $(this);

		if (!$item.hasClass('disabled')) {
			navListItems.removeClass('button').addClass('button primary');
			$item.addClass('button');
			allWells.hide();
			allErrors.hide();
			$target.show();
			$target.find('input:eq(0)').focus();
		}
	});

	allNextBtn.click(function() {

		var curStep = $(this).closest(".setup-content"),
		curStepBtn = curStep.attr("id"),
		nextStepWizard = $('div.setup-panel div a[href="#' + curStepBtn + '"]').parent().next().children("a"),
		curInputs = curStep.find("input[type='email'],input[type='text'],input[type='url'], input[type='radio'] "),
		isValid = true;
		$("label.error").hide();

		$("input").removeClass("is-invalid-input");
		for (var i = 0; i < curInputs.length; i++) {
			if (!curInputs[i].validity.valid) {
				isValid = false;
				$(curInputs[i]).closest("input").addClass("is-invalid-input");
				$(curInputs[i]).closest('fieldset').children('label.error').show();
			}
		}

		if (isValid) {
			if (curStepBtn == 'step-4') {
				/*Deal with autocomplete*/
				signup.addData('firstName', document.getElementById('first-name').value);
				signup.addData('lastName', document.getElementById('last-name').value);
				dataLayer.push({ 
					'event': 'step-3' }); 	
				$.when(signup.completeSignup()).then(function(){
					nextStepWizard.removeClass('disabled').trigger('click');
					return;
				});			
			}
			if (curStepBtn == 'step-1') {
				dataLayer.push({ 
					'event': 'step-1'  }); 	
				/* Deal with autocomplete */
				signup.addData('email', document.getElementById('email').value);
			}
			if (curStepBtn == 'step-2') {
				dataLayer.push({ 
					'event': 'step-2'  }); 	
			}
			$.when(signup.sendData()).then(function(){
				nextStepWizard.removeClass('disabled').trigger('click');
			});
		}
	});

	$('#step-1').show();

	$(document).on('keyup keypress', 'form input', function(e) {
		if(e.which == 13) {
			e.preventDefault();
		}
	});
});

// scroll magic
var controller = new ScrollMagic.Controller({
	globalSceneOptions: {
		triggerHook: 'onLeave',
		duration: "100%"
	}
});

AOS.init();

$(document).foundation();
