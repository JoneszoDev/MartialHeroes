function gpSignupData (apiBase, charityId, campaignId) {
    this.apiBase = apiBase;
    this.charityId = charityId;
    this.campaignId = campaignId;
    this.signUpId = generateGuid();
    this.coreData = {dirty: false,
                     status: 'creating'};
    this.additionalData = {dirty: false};
    this.coreDataKeys = ['firstName','lastName','email','templateChallengeId','groups','isOptedInToMarketing'];
}

gpSignupData.prototype.addData = function(key, value) {
    if (this.coreDataKeys.indexOf(key)===-1) {
        return this._addAdditionalData(key,value);
    }
    return this._addCoreData(key,value);
}

gpSignupData.prototype.setGroup = function(groupId, groupValue) {
    if (!this.coreData.hasOwnProperty('groups')) {
        this.coreData.groups = [];
    }
    var groupCurrentValue = '';
    var foundGroupSetting = false;
    var foundGroupIndex = 0;
    for(var i = 0; i < this.coreData.groups.length; i++) {
        if (this.coreData.groups[i].groupingId == groupId) {
            groupCurrentValue = this.coreData.groups[i].groupId;
            foundGroupSetting = true;
            foundGroupIndex = i;
            break;
        }
    }
    if (foundGroupSetting && groupCurrentValue == groupValue){
        return false;
    }
    this.coreData.groups.splice(foundGroupIndex,1);
    this.coreData.groups.push({groupingId: groupId, groupId: groupValue});
    this.coreData.dirty = true;
    return true;
}

gpSignupData.prototype._addCoreData = function(key, value) {
    if (this.coreData.hasOwnProperty(key) && this.coreData[key] == value){
        return false;
    }
    this.coreData[key] = value;
    this.coreData.dirty = true;
    return true;
}

gpSignupData.prototype._addAdditionalData = function(key, value) {
    if (this.additionalData.hasOwnProperty(key) && this.additionalData[key] == value){
        return false;
    }
    this.additionalData[key] = value;
    this.additionalData.dirty = true;
    return true;
}

gpSignupData.prototype._sendCoreDataToApi = function() {
    var defer = $.Deferred ();
    var dataToSend = this.coreData;
    dataToSend.id = this.signUpId;
    dataToSend.campaignId = this.campaignId;
    delete dataToSend.dirty; 
    $.ajax({
        type: 'PUT',
        url: this.apiBase + '/charities-campaigns-signups/charities/' + this.charityId + '/campaigns/' + this.campaignId + '/signUps/' + this.signUpId,
        contentType: 'application/json',
        data: JSON.stringify(dataToSend),  
        context: this,
    }).done (function(response) {  
        this.coreData.dirty = false;
        defer.resolve(response);
    }).fail(function (error) {
        this.additionalData.dirty = true;
        console.error ('Error sending data (' + error.status + '): ' + error.statusText);
        defer.reject(error.status);
    }); 
    return defer.promise();
}

gpSignupData.prototype._sendAdditionalDataToApi = function() {
    var defer = $.Deferred();
    var dataToSend = this.additionalData;
    delete dataToSend.dirty; 

    $.ajax({
        type: 'PATCH',
        url: this.apiBase + '/charities-campaigns-signups/charities/' + this.charityId + '/campaigns/' + this.campaignId + '/signUps/' + this.signUpId + '/questions',
        contentType: 'application/json',
        data: JSON.stringify(dataToSend),  
        context: this, 
    }).done (function(response) {  
        this.additionalData.dirty = false;
        defer.resolve(response);
    }).fail(function (error) {
        this.additionalData.dirty = true;
        console.error ('Error sending data (' + error.status + '): ' + error.statusText);
        defer.reject(error.status);
    }); 
    return defer.promise();
}

gpSignupData.prototype.sendData = function () {
    var defer = $.Deferred ();
    var thisInstance = this;

    if (this.coreData.dirty == false && this.additionalData.dirty == false) {
        defer.resolve(false);
    }

    if (this.coreData.dirty == true && this.additionalData.dirty == true) {
        this._sendAdditionalDataToApi().done(function(){
            thisInstance._sendCoreDataToApi().done(function(){
                defer.resolve(true);
            }).fail(function(){
                defer.reject(false);
            });
        }).fail(function(){
            defer.reject(false);
        });
    }

    if (this.coreData.dirty == true && this.additionalData.dirty == false) {
        this._sendCoreDataToApi().done(function(){
            defer.resolve(true);
        }).fail(function(){
            defer.reject(false);
        });
    }

    if (this.coreData.dirty == false && this.additionalData.dirty == true) {
        this._sendAdditionalDataToApi().done(function(){
            defer.resolve(true);
        }).fail(function(){
            defer.reject(false);
        });
    }

    return defer.promise();
}

gpSignupData.prototype.completeSignup = function () {
    this.coreData.status = 'submitted';
    this.coreData.dirty = true;
    return this.sendData();
}

function generateGuid () { 
    var d = new Date().getTime();
    if (typeof performance !== 'undefined' && typeof performance.now === 'function') {
        d += performance.now(); 
    }
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        const r = (d + Math.random() * 16) % 16 | 0;
        d = Math.floor(d / 16);
        return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
    });
}

$.ajax = (function ($oldAjax) {
    function check(a,b,c){
        var shouldRetry = b != 'success' && b != 'parsererror';
        if( shouldRetry && --this.retries > 0 )
            setTimeout(function () { $.ajax(this) }, this.retryInterval || 100);
    }

    return function(settings) {
        return $oldAjax(settings).always(check);
    }
})($.ajax); 