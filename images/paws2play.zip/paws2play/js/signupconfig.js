if (gpenvEnvironment.toLowerCase() == 'production') {
    var p2pConfig = {   apiBase: gpenvApiBase.substr(0, gpenvApiBase.length - 1),
                    charityId: 'ede4d076-b311-426f-bb2a-2355abb4cf17',
                    campaignId: 'b84903da-ec2b-149f-2883-f98496560ac5',
                    teamGroupsId: '9f504c30-9298-42c5-9e28-0a55c2d3efc0',
                    teamDogGroupId: '87142a2f-8c1a-4ed9-8b31-b68c087b1c75',
                    teamCatGroupId: '562c6b60-dcbb-43ba-ab4c-f4ec59a0c1b5',
                    teamRabbitGroupId: '97a11cf8-50a1-491e-aa29-a4d132fceb48',
                    teamHorseGroupId: 'e4e1c25c-cfa1-4c20-8443-2a2ce70a7922',
                    twitchTemplateId: '91420c6a-2ae1-3cb3-2c0d-601d71b0a72c',
                    mixerTemplateId: '8034a4cf-c0b8-fc91-a64f-999ae2e31082',
                    youtubeTemplateId: '97d7aeda-181c-7614-7dbc-472d9b3c4b02' };
}

else {
    var p2pConfig = {   apiBase: gpenvApiBase.substr(0, gpenvApiBase.length - 1),
        charityId: 'be24ef1c-0b10-4e5e-98d2-2d7429282910',
        campaignId: '06d85f5e-5a69-436c-8689-6e02d1fd26f3',
        teamGroupsId: '06d85f5e-5a69-436c-8689-6e02d1fd26f3',
        teamDogGroupId: '06d85f5e-5a69-436c-8689-6e02d1fd26f3',
        teamCatGroupId: '06d85f5e-5a69-436c-8689-6e02d1fd26f3',
        teamRabbitGroupId: '06d85f5e-5a69-436c-8689-6e02d1fd26f3',
        teamHorseGroupId: '06d85f5e-5a69-436c-8689-6e02d1fd26f3',
        twitchTemplateId: '06d85f5e-5a69-436c-8689-6e02d1fd26f3',
        mixerTemplateId: '06d85f5e-5a69-436c-8689-6e02d1fd26f3',
        youtubeTemplateId: '06d85f5e-5a69-436c-8689-6e02d1fd26f3' };

}