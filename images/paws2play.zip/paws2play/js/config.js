var gpenvApiBase = '#{ApiBaseUrlWithTrailingSlash}#';
var gpenvEnvironment = '#{Environment}#';

if (gpenvApiBase.charAt(0) == '#') {
    gpenvApiBase = 'https://api.gptest.uk/';
}